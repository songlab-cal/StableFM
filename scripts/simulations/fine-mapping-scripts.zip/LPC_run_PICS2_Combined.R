################################################################################
############# Run on PICS2 (Combined) on Gene Expression Phenotype  ############
################################################################################
# Date: Sep 27, 2024

#### Define directories and load packages --------------------------------------
library(dplyr)
library(logr)
library(doParallel)

## Global variables
LOCAL <- FALSE # Toggle between TRUE and FALSE
PHI_VECTOR <- c(0.05,0.1,0.2,0.4)
S_VECTOR <- c(1,2,3)
NO_REPS <- 2
N_PERMS <- 500
USER_L <- 3

if (LOCAL) {
  pics2_dir <- "/Users/alanaw/Documents/GitHub/het-and-strat/scripts/"
  sim_phenos_dir <- "/Users/alanaw/Documents/het_and_strat/082824/"
  geno_dir <- "/Users/alanaw/Documents/het_and_strat/genotypes/"
  snp_metadata_dir <- "/Users/alanaw/Documents/het_and_strat/genotypes/"
  gene_metadata_dir <- "/Users/alanaw/Documents/het_and_strat/"
  pop_metadata_dir <- "/Users/alanaw/Documents/het_and_strat/"
  out_dir <- "/Users/alanaw/Documents/het_and_strat/092724/"
} else {
  pics2_dir <- "/home/alanaw1/het_and_strat/PICS2/"
  sim_phenos_dir <- "/home/alanaw1/het_and_strat/082824/"
  geno_dir <- "/home/alanaw1/het_and_strat/genotypes/"
  snp_metadata_dir <- "/home/alanaw1/het_and_strat/genotypes/"
  gene_metadata_dir <- "/home/alanaw1/het_and_strat/"
  pop_metadata_dir <- "/home/alanaw1/het_and_strat/"
  out_dir <- "/home/alanaw1/het_and_strat/092724/"
}

## Read in the number of causal variants
args = commandArgs(trailingOnly=TRUE)
CHROMOSOME <- args[1] # Change this 
message(date(), ": Working on simulated gene expression phenotypes in Chr ",
        CHROMOSOME)

#### Main Body -----------------------------------------------------------------
## Source PICS2 functions
source(paste0(pics2_dir,"runPICS2.R"))

## Read metadata and sampled genes -- do once!
pop_metadata <- data.table::fread(paste0(pop_metadata_dir, "E-GEUV-1_subset_pop_anno.txt"))
sampled_genes <- readr::read_csv(paste0(gene_metadata_dir, 'sampled_genes.csv'))
sampled_genes$index <- 1:100
rel_sampled_genes <- sampled_genes %>% subset(CHR==CHROMOSOME)
rel_indices <- rel_sampled_genes$index

## Read genotype matrix, snp metadata file (do it once to save time)
genotype_data <- readr::read_csv(paste0(geno_dir, 
                                        "chr", CHROMOSOME, 
                                        "_allele_dosage.csv"))

snp_metadata <- data.table::fread(paste0(snp_metadata_dir, 
                                         "1KG_chr", CHROMOSOME, 
                                         "_metadata.txt"))

covar_data <- readr::read_csv(paste0(covar_dir, 
                                     "covars_array.csv"))

Z.input <- covar_data[,-1]
ids <- genotype_data[,1]
genos <- genotype_data[,-1]
poly_snvs <- which(apply(genos, 2, var) != 0)
genotype_data <- genos[,poly_snvs]
snp_metadata <- snp_metadata[poly_snvs,]
colnames(genotype_data) <- snp_metadata$marker.ID  

## Run PICS2
big_res_df <- NULL
# Loop over seeds
for (i in rel_indices) {
  # Select relevant gene
  example_gene <- rel_sampled_genes %>% subset(index==i)
  
  # Restrict to relevant SNPs
  if (!is.na(example_gene[['TSS']])) {
    included_snps <- snp_metadata %>% 
      subset(physical.pos >= example_gene[['LEFT']] & physical.pos <= example_gene[['RIGHT']])
    genotype_data_res <- genotype_data %>% select(included_snps$marker.ID)
  } else {
    genotype_data_res <- genotype_data
  }

  for (phi in PHI_VECTOR) {
    for (num_causal_var in S_VECTOR) {
      # Create temp file location
      tmp <- file.path(paste0(out_dir,
                              "log/PICS2_combined_S",
                              num_causal_var,"_phi",phi,"_gene",
                              i,"_",format(Sys.Date(), "%m%d%y.log")))
      # Open log
      lf <- log_open(tmp)
      log_print(paste0(date(), ": Working on phi = ",phi, 
                       " and S = ", num_causal_var, 
                       ". This is Gene ", i, ": ", example_gene$GENE))
      # Load simulated true causal variants
      sim_gene_exp <- readRDS(paste0(sim_phenos_dir,"S",num_causal_var,
                                "_phi",phi,"_sampled_gene_",i,".rds"))
      
      message(date(),": Working on phi = ", 
              phi, " with S = ", num_causal_var, " causal variants.")
      # Run PICS2 on each rep
      for (rep in 1:NO_REPS) {
        rep_res <- sim_gene_exp[[rep]]
        # The SNPs returned are ordered in terms of the potential set
        user_result <- runPICS2(X=genotype_data_res, 
                                y=rep_res$GENE_EXP, 
                                pr_prob=NULL,
                                S=as.data.frame(pop_metadata[,-1]),
                                Z=Z.input,
                                resample_n=N_PERMS,
                                ld_thres=0.5,
                                L=USER_L,
                                option = "combined",
                                summarize = TRUE)
        message(date(),": Adding result for Rep ", rep)
        big_res_df <- rbind(big_res_df,
                            data.frame(Chr=CHROMOSOME,
                                       Index=i,
                                       Gene=example_gene$GENE,
                                       No_Background_Vars=dim(genotype_data_res)[2],
                                       Phi=phi,
                                       S=num_causal_var,
                                       Rep=rep,
                                       CausalSNPs=paste(rep_res$CAUSAL_VARIANTS,collapse=","),
                                       SNP1=user_result$VARIANT[1],
                                       SNP2=user_result$VARIANT[2],
                                       SNP3=user_result$VARIANT[3],
                                       PostProb1=user_result$POSTERIOR_PROB[1],
                                       PostProb2=user_result$POSTERIOR_PROB[2],
                                       PostProb3=user_result$POSTERIOR_PROB[3],
                                       SupportSize1=user_result$SUPPORT_SIZE[1],
                                       SupportSize2=user_result$SUPPORT_SIZE[2],
                                       SupportSize3=user_result$SUPPORT_SIZE[3]))
      }
    }
  }
}

message(date(), ": Saving all results")
readr::write_csv(big_res_df,
                 file=paste0(out_dir,"PICS2_Chr",CHROMOSOME,"_combined_results.csv"))
