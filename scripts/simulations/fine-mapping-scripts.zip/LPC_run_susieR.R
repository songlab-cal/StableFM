################################################################################
################## Run on SuSiE on Gene Expression Phenotype  ##################
################################################################################
# Date: Sep 24, 2024

#### Define directories and load packages --------------------------------------
library(dplyr)
library(logr)
#library(doParallel)
library(susieR)
## Global variables
LOCAL <- TRUE # Toggle between TRUE and FALSE
PHI_VECTOR <- c(0.05,0.1,0.2,0.4)
S_VECTOR <- c(1,2,3)
NO_REPS <- 2
USER_L <- 3

if (LOCAL) {
  pics2_dir <- "/Users/alanaw/Documents/GitHub/het-and-strat/scripts/"
  sim_phenos_dir <- "/Users/alanaw/Documents/het_and_strat/082824/"
  geno_dir <- "/Users/alanaw/Documents/het_and_strat/genotypes/"
  snp_metadata_dir <- "/Users/alanaw/Documents/het_and_strat/genotypes/"
  gene_metadata_dir <- "/Users/alanaw/Documents/het_and_strat/"
  pop_metadata_dir <- "/Users/alanaw/Documents/het_and_strat/"
  covar_dir <- "/Users/alanaw/Documents/het_and_strat/covariates/"
  out_dir <- "/Users/alanaw/Documents/het_and_strat/092424/"
} else {
  pics2_dir <- "/home/alanaw1/het_and_strat/PICS2/"
  sim_phenos_dir <- "/home/alanaw1/het_and_strat/082824/"
  geno_dir <- "/home/alanaw1/het_and_strat/genotypes/"
  snp_metadata_dir <- "/home/alanaw1/het_and_strat/genotypes/"
  gene_metadata_dir <- "/home/alanaw1/het_and_strat/"
  pop_metadata_dir <- "/home/alanaw1/het_and_strat/"
  covar_dir <- "/home/alanaw1/het_and_strat/covariates/"
  out_dir <- "/home/alanaw1/het_and_strat/092424/"
}

## Read in the number of causal variants
args = commandArgs(trailingOnly=TRUE)
CHROMOSOME <- args[1] # Change this 
message(date(), ": Running susieR on simulated gene expression phenotypes in Chr ",
        CHROMOSOME)

#### Main Body -----------------------------------------------------------------

## Read metadata and sampled genes -- do once!
pop_metadata <- data.table::fread(paste0(pop_metadata_dir, "E-GEUV-1_subset_pop_anno.txt"))
sampled_genes <- readr::read_csv(paste0(gene_metadata_dir, 'sampled_genes.csv'))
sampled_genes$index <- 1:100
rel_sampled_genes <- sampled_genes %>% subset(CHR==CHROMOSOME)
rel_indices <- rel_sampled_genes$index

## Read genotype matrix, snp metadata file, and genome-wide PCs (do it once to save time)
genotype_data <- readr::read_csv(paste0(geno_dir, 
                                        "chr", CHROMOSOME, 
                                        "_allele_dosage.csv"))

snp_metadata <- data.table::fread(paste0(snp_metadata_dir, 
                                         "1KG_chr", CHROMOSOME, 
                                         "_metadata.txt"))

covar_data <- readr::read_csv(paste0(covar_dir, 
                                     "covars_array.csv"))

Z.input <- covar_data[,-1]

ids <- genotype_data[,1]
genos <- genotype_data[,-1]
poly_snvs <- which(apply(genos, 2, var) != 0)
genotype_data <- genos[,poly_snvs]
snp_metadata <- snp_metadata[poly_snvs,]
colnames(genotype_data) <- snp_metadata$marker.ID  

## Run PICS2
big_res_df <- NULL
# Loop over seeds
for (i in rel_indices) {
  # Select relevant gene
  example_gene <- rel_sampled_genes %>% subset(index==i)
  
  # Restrict to relevant SNPs
  if (!is.na(example_gene[['TSS']])) {
    included_snps <- snp_metadata %>% 
      subset(physical.pos >= example_gene[['LEFT']] & physical.pos <= example_gene[['RIGHT']])
    genotype_data_res <- genotype_data %>% select(included_snps$marker.ID)
  } else {
    genotype_data_res <- genotype_data
  }

  for (phi in PHI_VECTOR) {
    for (num_causal_var in S_VECTOR) {
      # Create temp file location
      # tmp <- file.path(paste0(out_dir,
      #                         "log/PICS2_S",
      #                         num_causal_var,"_phi",phi,"_gene",
      #                         i,"_susieR_",format(Sys.Date(), "%m%d%y.log")))
      # Open log
      # lf <- log_open(tmp)
      # log_print(paste0(date(), ": Working on phi = ",phi, 
      #                  " and S = ", num_causal_var, 
      #                  ". This is Gene ", i, ": ", example_gene$GENE))
      # Load simulated true causal variants
      sim_gene_exp <- readRDS(paste0(sim_phenos_dir,"S",num_causal_var,
                                "_phi",phi,"_sampled_gene_",i,".rds"))
      
      message(date(),": Working on phi = ", 
              phi, " with S = ", num_causal_var, " causal variants.")
      # Run PICS2 on each rep
      for (rep in 1:NO_REPS) {
        rep_res <- sim_gene_exp[[rep]]
        print("Hex1")
        print(data.frame(y=rep_res$GENE_EXP))
        print(Z.input)
        lm.input.df <- cbind(data.frame(y=rep_res$GENE_EXP),
                             Z.input)
        print("Hex2")
        colnames(lm.input.df)
        print("Hex3")
        y_residuals <- lm(y~.-1, data = lm.input.df)$residuals 
        # remove intercept, because PCs are already standardized
        print("Hex4")
        # Run susieR here
        res <- susie(X=as.matrix(genotype_data_res),
                     y=y_residuals,
                     L=USER_L)
        
        # Extract PIPs for each credible set
        pip_vec_1 <- res$alpha[1,] 
        pip_vec_2 <- res$alpha[2,] 
        pip_vec_3 <- res$alpha[3,] 
        
        # Add results to dataframe
        message(date(),": Adding result for Rep ", rep)
        # Return NA for SNP if susieR posterior probability is identical across all SNPs
        big_res_df <- rbind(big_res_df,
                            data.frame(Chr=CHROMOSOME,
                                       Index=i,
                                       Gene=example_gene$GENE,
                                       No_Background_Vars=dim(genotype_data_res)[2],
                                       Phi=phi,
                                       S=num_causal_var,
                                       Rep=rep,
                                       CausalSNPs=paste(rep_res$CAUSAL_VARIANTS,collapse=","),
                                       SNP1=ifelse(length(which(pip_vec_1==max(pip_vec_1)))==ncol(genotype_data_res),
                                                   NA,
                                                   paste(names(which(pip_vec_1==max(pip_vec_1))),collapse=",")),
                                       SNP2=ifelse(length(which(pip_vec_2==max(pip_vec_2)))==ncol(genotype_data_res),
                                                   NA,
                                                   paste(names(which(pip_vec_2==max(pip_vec_2))),collapse=",")),
                                       SNP3=ifelse(length(which(pip_vec_3==max(pip_vec_3)))==ncol(genotype_data_res),
                                                   NA,
                                                   paste(names(which(pip_vec_3==max(pip_vec_3))),collapse=",")),
                                       PostProb1=max(pip_vec_1),
                                       PostProb2=max(pip_vec_2),
                                       PostProb3=max(pip_vec_3),
                                       SupportSize1=sum(pip_vec_1>1e-15),
                                       SupportSize2=sum(pip_vec_2>1e-15),
                                       SupportSize3=sum(pip_vec_3>1e-15),
                                       CredibleSet1_95=ifelse(!is.null(susie_get_cs(res)[["cs"]][["L1"]]),
                                                              susie_get_cs(res)[["cs"]][["L1"]],
                                                              NA),
                                       CredibleSet2_95=ifelse(!is.null(susie_get_cs(res)[["cs"]][["L2"]]),
                                                              susie_get_cs(res)[["cs"]][["L2"]],
                                                              NA),
                                       CredibleSet3_95=ifelse(!is.null(susie_get_cs(res)[["cs"]][["L3"]]),
                                                              susie_get_cs(res)[["cs"]][["L3"]],
                                                              NA)))
      }
    }
  }
}

message(date(), ": Saving all results")
readr::write_csv(big_res_df,
                 file=paste0(out_dir,"PICS2_Chr",CHROMOSOME,"_susieR_L3_results.csv"))
