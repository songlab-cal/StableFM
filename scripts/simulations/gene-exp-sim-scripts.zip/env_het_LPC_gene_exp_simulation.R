################################################################################
#################### Gene Expression Phenotype Simulations #####################
################################################################################
# Date: Jan 29, 2025
# Modified to include heterogeneous environmental variable.
# Heterogeneity is induced by having a mean shift in the exogenous variable. 
# This shift is included for JUST one subpopulation, unlike v2.

#### Define directories and load packages --------------------------------------
library(dplyr)
library(logr)
LOCAL <- FALSE
POWER <- 0

if (LOCAL) {
  geno_dir <- "/Users/alanaw/Documents/het_and_strat/genotypes/"
  snp_metadata_dir <- "/Users/alanaw/Documents/het_and_strat/genotypes/"
  gene_metadata_dir <- "/Users/alanaw/Documents/het_and_strat/"
  pop_metadata_dir <- "/Users/alanaw/Documents/het_and_strat/"
  out_dir <- "/Users/alanaw/Documents/het_and_strat/013025/"
} else {
  geno_dir <- "/home/alanaw1/het_and_strat/genotypes/"
  snp_metadata_dir <- "/home/alanaw1/het_and_strat/genotypes/"
  gene_metadata_dir <- "/home/alanaw1/het_and_strat/"
  pop_metadata_dir <- "/home/alanaw1/het_and_strat/"
  out_dir <- "/home/alanaw1/het_and_strat/013025/"
}


## Global variables
PHI_VECTOR <- c(0.05,0.1,0.2,0.4)
NO_REPS <- 2

## Read in the number of causal variants
args = commandArgs(trailingOnly=TRUE)
num_causal_var <- args[1] # Number of causal variants

#### Helper function -----------------------------------------------------------
generateGeneExpression <- function(example_gene,
                                   phi,
                                   num_causal_var,
                                   no_reps,
                                   pow) {
  # Read metadata
  snp_metadata <- data.table::fread(paste0(snp_metadata_dir, "1KG_chr", example_gene[['CHR']], "_metadata.txt"))
  pop_metadata <- data.table::fread(paste0(pop_metadata_dir, "E-GEUV-1_subset_pop_anno.txt"))
  
  subpop_samp_sizes <- colSums(pop_metadata[,-1]) %>% as.numeric()
  var_multiplier_vec <- sapply(subpop_samp_sizes,function(x) {5/sum((subpop_samp_sizes/x)^pow)})
  #var_multiplier_vec <- subpop_samp_sizes^pow/sum(subpop_samp_sizes^pow)*5
  subpop_samp_sizes
  # Read genotype matrix 
  genotype_data <- read.csv(paste0(geno_dir, "chr", example_gene[['CHR']], "_allele_dosage.csv"))
  ids <- genotype_data[,1]
  genos <- genotype_data[,-1]
  poly_snvs <- which(apply(genos, 2, var) != 0)
  genotype_data <- genos[,poly_snvs]
  snp_metadata <- snp_metadata[poly_snvs,]
  colnames(genotype_data) <- snp_metadata$marker.ID  
  
  # Restrict to relevant SNPs
  if (!is.na(example_gene[['TSS']])) {
    included_snps <- snp_metadata %>% 
      subset(physical.pos >= example_gene[['LEFT']] & physical.pos <= example_gene[['RIGHT']])
    genotype_data <- genotype_data %>% select(included_snps$marker.ID)
  }
  
  # Simulate effect sizes and causal variants
  to_return <- vector("list",length=2)
  for (rep in 1:no_reps) {
    rep_list <- list(GENE_EXP=numeric(),
                     CAUSAL_VARIANTS=character(),
                     EFFECT_VECTOR=numeric(),
                     N_PARTICIPATING=numeric())
    effect_vector <- rep(0,ncol(genotype_data))
    causal_variants <- sample(1:length(effect_vector),num_causal_var)
    effect_vector[causal_variants] <- rnorm(n=length(causal_variants),
                                            mean=0,sd=0.6)
    selected_rsids <- colnames(genotype_data)[causal_variants]
    Xb <- as.numeric(as.matrix(genotype_data) %*% effect_vector) 
    sigma2 <- var(Xb) * (1-phi)/phi
    subpop_i_mat <- NULL
    # Create ancestry-specific environmental variable 
    for (i in 1:5) {
      subpop_i_noise <- rnorm(n=length(Xb),
                              mean=2*abs(i==3)*sqrt(sigma2*var_multiplier_vec[i]),
                              sd=sqrt(sigma2*var_multiplier_vec[i]))
      subpop_i_mat <- cbind(subpop_i_mat,subpop_i_noise)
    }
    noise_vec <- rowSums(subpop_i_mat*pop_metadata[,-1])
    simulated_gene_exp <- Xb + noise_vec
    rep_list[['GENE_EXP']] <- simulated_gene_exp
    rep_list[['CAUSAL_VARIANTS']] <- selected_rsids
    rep_list[['EFFECT_VECTOR']] <- effect_vector
    rep_list[['N_PARTICIPATING']] <- ncol(genotype_data)
    to_return[[rep]] <- rep_list
  }
  
  # Return gene expression vector, selected variants, and no. variants participating in fine-mapping
  return(to_return)
}

#### Main Body -----------------------------------------------------------------
## Read in sampled genes array
sampled_genes <- readr::read_csv(paste0(gene_metadata_dir, 'sampled_genes.csv'))
## Save results for all genes
for (phi in PHI_VECTOR) {
  # Create temp file location
  tmp <- file.path(paste0(out_dir,
                          "log/S",
                          num_causal_var,"_phi",phi,"_",
                          format(Sys.Date(), "%m%d%y.log")))
  # Open log
  lf <- log_open(tmp)
  log_print(paste0(date(), ": Working on phi = ",phi, 
                   " and S = ", num_causal_var))
  log_print(paste0(date(), 
                   ": Note that gene IDs can be found at /home/alanaw1/het_and_strat/sampled_genes.csv"))
  for (i in c(1:5,96:100)) {
    log_print(paste0(date(), ": Simulating gene expression data ", i, 
                     ", including ancestral-conditioned environmental noise"))
    example_gene <- sampled_genes[i,]
    results <- generateGeneExpression(example_gene=example_gene,
                                      phi=phi,
                                      num_causal_var=num_causal_var,
                                      no_reps=NO_REPS,
                                      pow=POWER)
    log_print(str(results))
    saveRDS(results, file = paste0(out_dir, 
                                   "S", num_causal_var, 
                                   "_phi", phi, "_sampled_gene_", i, 
                                   ".rds"))
  }
  
  # Close stream and write to log file
  log_close()
  writeLines(readLines(lf))
}
